﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Member
    {
        public string mNo { set; get; }
        public string mName { set; get; }
        public string Age { set; get; }
        public string Sex { set; get; }
        public string phone { set; get; }
        public string address { set; get; }
        public string locker { set; get; }
    }
}
