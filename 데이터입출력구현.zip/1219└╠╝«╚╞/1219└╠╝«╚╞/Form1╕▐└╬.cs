﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1219이석훈
{
    public partial class Form1메인 : Form
    {
        
        private MySqlConnection conn;
        Form2목록 f2;
        public Form1메인()
        {
            InitializeComponent();
            Load += Form1메인_Load;
        }

        private void Form1메인_Load(object sender, EventArgs e)
        {
            button1.Click += Button1_Click;
            button2.Click += Button2_Click;
            listView1.MouseClick += ListView1_MouseClick;
            listView1.FullRowSelect = true;

            conn = new MySqlConnection();
            string server = "192.168.3.29";
            string user = "root";
            string password = "1234";
            string db = "test";
            conn.ConnectionString = string.Format("server={0};user={1};password={2};database={3}",
                server, user, password, db);

            try
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand();
                comm.CommandText = "pr_select";
                comm.Connection = conn;
                comm.CommandType = CommandType.StoredProcedure;
                MySqlDataReader sdr = comm.ExecuteReader();
                
                while (sdr.Read())
                {
                    string[] arr = new string[4];
                    for (int i = 0; i < sdr.FieldCount; i++)
                    {
                        arr[i] = sdr.GetValue(i).ToString();
                    }
                    listView1.Items.Add(new ListViewItem(arr));
                }
                sdr.Close();
                //conn.Close();
            }
            catch
            {
                MessageBox.Show("연결 실패");
            }


        }
                
        private void Button1_Click(object sender, EventArgs e)
        {
            

            MessageBox.Show("검색");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            f2 = new Form2목록();
            f2.ShowDialog();
        }

        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            conn = new MySqlConnection();
            string server = "192.168.3.29";
            string user = "root";
            string password = "1234";
            string db = "test";
            conn.ConnectionString = string.Format("server={0};user={1};password={2};database={3}",
                server, user, password, db);

            try
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand();
                comm.CommandText = "pr_count";
                comm.Connection = conn;
                comm.CommandType = CommandType.StoredProcedure;
                MySqlDataReader sdr = comm.ExecuteReader();
                listView1.Items.Clear();
                while (sdr.Read())
                {
                    string[] arr = new string[4];
                    for (int i = 0; i < sdr.FieldCount; i++)
                    {
                        arr[i] = sdr.GetValue(i).ToString();
                    }
                    listView1.Items.Add(new ListViewItem(arr));
                }
                sdr.Close();
                //conn.Close();
            }
            catch
            {
                MessageBox.Show("연결 실패");
            }
        }




    }
}
