﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1219이석훈
{
    public partial class Form2목록 : Form
    {
        private MySqlConnection conn;

        public Form2목록()
        {
            InitializeComponent();
            Load += Form2목록_Load;
            button1.Click += Button1_Click;
            //button2.Click += Button2_Click;
        }

        private void Form2목록_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //    conn = new MySqlConnection();
            //    string server = "192.168.3.29";
            //    string user = "root";
            //    string password = "1234";
            //    string db = "test";
            //    conn.ConnectionString = string.Format("server={0};user={1};password={2};database={3}",
            //        server, user, password, db);

            //    try
            //    {
            //        conn.Open();
            //        MySqlCommand comm = new MySqlCommand();
            //        comm.CommandText = "insert into board (title,contents,writer,passwd,count) values("테스트","내용","작가",1234,0)";
            //        comm.Connection = conn;
            //        comm.CommandType = CommandType.StoredProcedure;


            //        conn.Close();
            //    }
            //    catch
            //    {
            //        MessageBox.Show("연결 실패");
            //    }
            //}

            //private void Button2_Click(object sender, EventArgs e)
            //{
            //    MessageBox.Show("취소");
            //}
            
        }

    }
}
