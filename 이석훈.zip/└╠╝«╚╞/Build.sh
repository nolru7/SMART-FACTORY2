#!/bin/sh
###############################################################
# Service > systemd > dotnet.service
# Sample Project > /root
# ip Change > 192.168.3.104"
# MariaDB > user(root)/password(test) > table(test.board)
###############################################################

gitPath=https://github.com/nolru7/20190110_LSH.git
rootDir="/root"
projectDir="/Project"
repository_Dir="/20190110_LSH"
publishDir="${projectDir}/bin/Debug/netcoreapp2.1/publish"
serviceDir="/publish"

#빌드 대상 프로젝트 경로 확인
if [ -d $rootDir$projectDir ]; then
  rm -Rf $rootDir$projectDir
fi

if [ -d $rootDir$repository_Dir ] ; then
  rm -Rf $rootDir$repository_Dir
fi

# 1. GitHub Repository Download
cd ${rootDir}
git clone $gitPath
mv ${rootDir}${repository_Dir}${projectDir} ${rootDir}

# 2. Project Build
cd $rootDir$projectDir
dotnet build

# 3. Service Shutdown
systemctl stop dotnet.service

# 4. Project Publish
dotnet publish

# 5. Service Run
systemctl start dotnet.service

###############################################################
exit 0
